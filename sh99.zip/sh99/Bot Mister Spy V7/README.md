# MisterSpy-V7
My Last Bot V7 
install python 2.7.14
link :
https://www.python.org/downloads/release/python-2714/
Open Cmd write : 
cd C:\Python27
then
pip install requests
then
pip install colorama
then
pip install smtplib
then
pip install socket
any problem u can contact me in icq or facebook :
https://www.facebook.com/007MrSpy
icq : 712083179
\n Tuto
https://www.youtube.com/watch?v=pzsIsa6pvPw

          " " " " " " " " " " " " " " " " " " " "  "
          "                  ,__,                  "
          "                  (oo)____              "
          "                  (__)    )\            "
          "                     ||--|| *  V7       "
          "                                        "
          " " " " " " " " " " " " " " " " " " " "  "
